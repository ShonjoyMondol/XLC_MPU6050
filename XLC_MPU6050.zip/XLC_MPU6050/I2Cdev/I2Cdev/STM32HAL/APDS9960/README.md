Ported to C and HAL for STM32 from [Arduino driver](https://github.com/sparkfun/SparkFun_APDS-9960_Sensor_Arduino_Library)
